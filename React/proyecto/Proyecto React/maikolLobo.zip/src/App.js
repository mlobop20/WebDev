import logo from './logo.svg';
import './App.css';
import NavBar from './componentes/navBar/navBar';
import Footer from './componentes/footer/footer'
import Body from './componentes/body/body'
import ContactForm from './componentes/formularioContacto/formularioContacto.js';
import ListaElementosAplv from './componentes/ListaElementosAplv/ListaElementosAplv';


function App() {
  return (
    <div>
      <NavBar></NavBar>
      <Body></Body>
      <ListaElementosAplv aplv={['Leche', 'Yogurt', 'Queso', 'Natilla']}></ListaElementosAplv>

      <ContactForm></ContactForm>

      <Footer></Footer>
    </div>
  );
}

export default App;
