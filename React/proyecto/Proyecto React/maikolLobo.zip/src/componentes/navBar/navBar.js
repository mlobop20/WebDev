import React, { Component } from 'react';
import './navBar.css';

function loggueoMensaje(e) {
  e.preventDefault();
  alert("Se ha logueado en nuestra página web");
}

export default class Eventos extends Component {
  render() {
    return (
      <nav className="navbar navbar-expand-lg navbar-light bg-primary">
        <div className="container-fluid">
          <div className="navbar-brand">Todo sobre APLV</div>
          <img src="./icon.jpeg" alt="Logo" />
        </div>

        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav me-auto mb-2 mb-lg-0">
            <li className="nav-item">
              <a className="nav-link" href="#">Inicio</a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">Productos</a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">Información</a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">Servicios</a>
            </li>
            <li className="nav-item" onClick={loggueoMensaje}>
              <a className="nav-link" href="#">Login</a>
            </li>
          </ul>
        </div>
      </nav>
    );
  }
}
