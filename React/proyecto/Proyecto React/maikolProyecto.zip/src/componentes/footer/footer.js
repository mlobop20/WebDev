
import './footer.css';
import React, { Component } from 'react'

export default class Footer extends Component {
  render() {
    return (
      <div className="footer">
        <div className="">
          <span> Hecho en Costa Rica por Maikol Lobo!</span>
        </div>

      </div>)
  }
}
