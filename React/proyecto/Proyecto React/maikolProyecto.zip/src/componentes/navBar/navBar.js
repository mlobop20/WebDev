import React from 'react';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
import ContactForm from '../formularioContacto/formularioContacto';
import Body from '../body/body';
import { Componente } from '../componente/componente';

export default function NavBar() {
    return (
        <Router>
            <ul className="nav bg-dark">
                <li className="nav-item">
                    <Link to="/" className="nav-link">Inicio</Link>
                </li>
                <li className="nav-item">
                    <Link to="/productos" className="nav-link">Productos</Link>
                </li>
                <li className="nav-item">
                    <Link to="/informacion" className="nav-link">Información</Link>
                </li>
                <li className="nav-item">
                    <Link to="/servicios" className="nav-link">Servicios</Link>
                </li>
                <li className="nav-item">
                    <Link to="/contacto" className="nav-link">Contacto</Link>
                </li>
            </ul>

            <Switch>
                <Route path="/productos">
                    <Productos />
                </Route>
                <Route path="/informacion">
                    <Informacion />
                </Route>
                <Route path="/servicios">
                    <Servicios />
                </Route>
                <Route path="/contacto">
                    <Contacto />
                </Route>
                <Route path="/">
                    <Inicio />
                </Route>
            </Switch>
        </Router>
    );
}

function Inicio() {
    return <Body />;
}

function Productos() {
    return <Componente />;
}

function Informacion() {
    return <h2>Información</h2>;
}

function Servicios() {
    return <h2>Servicios</h2>;
}

function Contacto() {
    return <ContactForm />;
}
