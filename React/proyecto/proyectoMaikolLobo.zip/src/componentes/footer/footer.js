
import './footer.css';


function Footer() {

  return (
<div class="footer">
<div class="">
  <span> Hecho en Costa Rica por Maikol Lobo!</span>
</div>

</div>
  );

}


export default Footer;