import './body.css';


function Body() {

  return (
<div class="body">
<div class="">
  <h1>Bienvenido a la mejor fuente de información sobre la alergia a la preteina de la leche de vaca</h1>
</div>

</div>
  );

}


export default Body;