import { input, div, h1, th, table, tr, td, button } from './html.js'
import { Persona } from './persona.js';

window.addEventListener('load', main)
function main() {

    var formDatos = document.getElementById('formDatos');
    h1(formDatos, { id: 'mainTitle', className: 'main_title', innerHTML: 'Cliente' })
    var nombreIn = input(formDatos, { id: 'nombreIn', className: 'm-1', placeholder: 'Nombre' });
    var apellidoIn = input(formDatos, { id: 'apellidoIn', className: 'm-1', placeholder: 'Apellido' });
    var correoIn = input(formDatos, { id: 'correoIn', className: 'm-1', placeholder: 'E-mail' });
    var fondosIn = input(formDatos, { id: 'fondosIn', className: 'm-1', placeholder: 'Fondos disponibles' });
    var mensualidadIn = input(formDatos, { id: 'mensualidadIn', className: 'm-1', placeholder: 'Mensualidad' });
    var guardarBtn = button(formDatos, { type: 'button', id: 'guardarBtn', className: 'btn btn-primary m-1', innerHTML: 'Guardar' });
    var cancelarBtn = button(formDatos, { id: 'cancelarBtn', className: 'btn btn-danger m-1', innerHTML: 'Cancelar' });

    var clientesArray = [];
    limpiar();

    function guardarInfo() {
        if (nombreIn.value === "" || apellidoIn.value === "" || correoIn.value === "" || fondosIn.value === "" || mensualidadIn.value === "") {
            alert('Debe de rellenar todos los campos!')

        } else {
            const persona = new Persona(nombreIn.value, apellidoIn.value, correoIn.value, fondosIn.value, mensualidadIn.value);
            clientesArray.push(persona);
            console.log(persona);
            actualizarTabla();
            limpiar()
        }
    }



    clientesArray.every((cliente, index) => {
        if (cliente.email === email) {
            datosCorrectos = false;
            alert('Email agregado anteriormente!');
            return true;
        }
    });


    function limpiar() {
        nombreIn.value = "";
        apellidoIn.value = "";
        correoIn.value = "";
        fondosIn.value = "";
        mensualidadIn.value = "";
    }

    guardarBtn.onclick = function () {
        guardarInfo();
    }

    function mostrarInfo() {

    }


    var clientesTabla = table(formDatos, { className: 'clientesTabla' });

    // estudiantes.every(estudiante => {
    //     var tableRow = tr(estudiantesTable);
    //     var tableData = td(tableRow, { innerHTML: estudiante.nombre });
    //     tableData = td(tableRow, { innerHTML: estudiante.apellido });
    //     tableData = td(tableRow, { innerHTML: estudiante.email });
    //     return true;
    // });

    function actualizarTabla() {
        clientesTabla.innerHTML = '';
        var tableRow = tr(clientesTabla);
        var tableHeader = th(tableRow, { innerHTML: 'Nombre' })
        var tableHeader = th(tableRow, { innerHTML: 'Apellido' })
        var tableHeader = th(tableRow, { innerHTML: 'Email' })
        var tableHeader = th(tableRow, { innerHTML: 'Fondos disponibles' })
        var tableHeader = th(tableRow, { innerHTML: 'Mensualidad' })
        clientesArray.every(clientes => {
            var tableRow = tr(clientesTabla);
            var tableData = td(tableRow, { innerHTML: clientes.nombre });
            tableData = td(tableRow, { innerHTML: clientes.apellido });
            tableData = td(tableRow, { innerHTML: clientes.email });
            tableData = td(tableRow, { innerHTML: clientes.fondos });
            tableData = td(tableRow, { innerHTML: clientes.mensualidad });
            return true;
        });
    }

}