export class Difficulty{
    constructor(){
        
    }
}