export class DifficultyService{
    constructor(){
        
    }
}