export class Card{
    constructor(){
        
    }
}