export class MenuService{
    constructor(){
        
    }
}