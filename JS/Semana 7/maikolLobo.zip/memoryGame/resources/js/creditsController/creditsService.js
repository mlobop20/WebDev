export class CreditsService{
    constructor(){
        
    }
}