import { GameManager } from "./gameManager.js"

window.addEventListener('load', main)
function main() { 

    const gameManager = new GameManager();

}