export class Login{
    constructor(){
        
    }
}